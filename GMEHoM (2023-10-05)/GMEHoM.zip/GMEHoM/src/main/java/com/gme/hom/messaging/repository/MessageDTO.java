package com.gme.hom.messaging.repository;

public class MessageDTO {
	
	

}
