package com.gme.hom.users.repository;

public interface UserDTO {

	String getFirst_name();

	String getLast_name();

	String getEmail_id();

	String getUsername();

	String getRoles();
}
