package com.gme.pp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmeHoMApplicationTests {

	@Test
	void contextLoads() {
	}

}
