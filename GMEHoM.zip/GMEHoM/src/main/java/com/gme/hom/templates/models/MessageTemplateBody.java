package com.gme.hom.templates.models;

public interface MessageTemplateBody {
	public String buildMessage();
}
