package com.gme.hom.merchants.config;

public class MerchantResponseMessages {

}
