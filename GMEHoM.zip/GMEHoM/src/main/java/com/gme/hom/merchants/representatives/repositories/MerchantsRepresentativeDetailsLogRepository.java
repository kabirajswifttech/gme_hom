package com.gme.hom.merchants.representatives.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gme.hom.merchants.representatives.model.MerchantsRepresentativeDetailsLog;

public interface MerchantsRepresentativeDetailsLogRepository extends JpaRepository<MerchantsRepresentativeDetailsLog, Long> {

}
