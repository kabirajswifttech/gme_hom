package com.gme.hom.merchants.bankDetails.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gme.hom.merchants.bankDetails.model.MerchantsBankDetailsLog;

public interface MerchantsBankDetailsLogRepository extends JpaRepository<MerchantsBankDetailsLog, Long>{

}
