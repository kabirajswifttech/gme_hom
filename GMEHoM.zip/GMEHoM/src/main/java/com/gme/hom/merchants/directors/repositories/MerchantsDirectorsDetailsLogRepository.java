package com.gme.hom.merchants.directors.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gme.hom.merchants.directors.model.MerchantsDirectorsDetailsLog;

public interface MerchantsDirectorsDetailsLogRepository extends JpaRepository<MerchantsDirectorsDetailsLog, Long> {

}
