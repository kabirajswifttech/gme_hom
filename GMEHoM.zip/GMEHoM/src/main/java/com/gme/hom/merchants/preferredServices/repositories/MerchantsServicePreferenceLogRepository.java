package com.gme.hom.merchants.preferredServices.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gme.hom.merchants.preferredServices.model.MerchantsServicePreferenceLog;

public interface MerchantsServicePreferenceLogRepository extends JpaRepository<MerchantsServicePreferenceLog, Long> {

}
