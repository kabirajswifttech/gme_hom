package com.gme.hom.merchants.owners.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gme.hom.merchants.owners.model.MerchantsOwnersDetailsLog;

public interface MerchantsOwnersDetailsLogRepository extends JpaRepository<MerchantsOwnersDetailsLog, Long> {

}
