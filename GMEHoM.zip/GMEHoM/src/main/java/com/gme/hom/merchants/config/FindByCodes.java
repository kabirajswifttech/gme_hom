package com.gme.hom.merchants.config;

public enum FindByCodes {
	MERCHANT_ID
}
