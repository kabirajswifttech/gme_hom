package com.gme.hom.security.config;

public final class SecurityConstants {

	/*
	 * 
	 * public static final int TIMEOUT_HOURS = 24; // in hours
	 * 
	 * public static final int JWT_TOKEN_TIMEOUT = TIMEOUT_HOURS * 60 * 60 * 1000;
	 * // in milliseconds public static final String JWT_SECRET =
	 * "pram0d4gm3h0mWalongkeyfortheJWTtokenwintercastleIsCold";
	 * 
	 * public static final int COOKIE_MAX_AGE = TIMEOUT_HOURS * 60 * 60; // in
	 * seconds
	 * 
	 * public static final int OTP_MAX_AGE = 10; // in minutes
	 * 
	 * public static final String DEDUPHASH = "MD5"; public static final String
	 * ROWHASH = "SHA256";
	 */
}
