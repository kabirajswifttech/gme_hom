package com.gme.hom.api.config;

public final class APIDataTypes {

	public static final String LONG = "LONG";
	public static final String CATEGORY = "CATEGORY";
}
