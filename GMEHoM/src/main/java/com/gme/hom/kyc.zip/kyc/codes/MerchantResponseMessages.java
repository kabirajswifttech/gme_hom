package com.gme.hom.kyc.codes;

public class MerchantResponseMessages {

}
