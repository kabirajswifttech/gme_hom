package com.gme.hom.kyc.merchants.config;

public enum FindByCodes {
	MERCHANT_ID
}
